# PRIVACY POLICY MODEL FOR MOBILE APPLICATIONS
This privacy policy governs your use of the software application “Face Recognition” for mobile devices that was created by Michael Sladoje and Mike Schälchli. The Application is used as a framework for Android devices to test different face recognition methods.
## What information does the Application obtain and how is it used?
None
## Does the Application collect precise real time location information of the device?
No
## Do third parties see and/or have access to information obtained by the Application?
No
## Contact us
If you have any questions regarding privacy while using the Application, or have questions about our practices, please contact us via email at qualeams@gmail.com.
