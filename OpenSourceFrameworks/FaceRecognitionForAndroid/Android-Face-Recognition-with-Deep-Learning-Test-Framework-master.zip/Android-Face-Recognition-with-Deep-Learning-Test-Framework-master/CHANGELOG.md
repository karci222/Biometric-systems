# Changelog

# Release 1.1.1

Initial release of Android Face Recognition with Deep Learning.
